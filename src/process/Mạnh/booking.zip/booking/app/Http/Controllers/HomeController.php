<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\City;
use App\Models\Hotel;


class HomeController extends Controller
{
    public function index()
    {
        $cities = City::with('hotels')->get();
        $hotels = Hotel::with('city')->orderBy('rank', 'asc')->take(5)->get();
        $hotels1 = Hotel::where('city_id', 1)->orderBy('rank', 'asc')->take(4)->get();
        $hotels3 = Hotel::where('city_id', 3)->orderBy('rank', 'asc')->take(4)->get();

        return view('common.home', compact('cities', 'hotels', 'hotels1', 'hotels3'));
    }

    public function city($slug, Request $request)
    {
        $sort_price = $request->input('sort_price');
        $price_min = $request->input('price_min');
        $price_max = $request->input('price_max');
        $hotels = Hotel::where('name', '<>', ' ');

        $star = array();

        if($request->input('star1') == 'on')
        {
            array_push($star,1);
        }
        if($request->input('star2') == 'on')
        {
            array_push($star,2);
        }
        if($request->input('star3') == 'on')
        {
            array_push($star,3);
        }
        if($request->input('star4') == 'on')
        {
            array_push($star,4);
        }
        if($request->input('star5') == 'on')
        {
            array_push($star,5);
        }
        if($star != [])
        {
            $hotels = $hotels->whereIn('stars', $star);

        }

        if(is_null($price_min) == False)
        {
            $hotels = $hotels->where('price', '>', $price_min);
        }
        if(is_null($price_max) == False)
        {
            $hotels = $hotels->where('price', '<', $price_max);
        }

        if($sort_price == 1)
        {
            $hotels = $hotels->orderBy('price', 'asc');
        }

        if($sort_price == 2)
        {
            $hotels = $hotels->orderBy('price', 'desc');
        }
        $city = City::where('slug', $slug)->first();
        $cities = City::with('hotels')->get();
        $hotels = $hotels->where('city_id', $city->id)->orderBy('rank', 'asc')->paginate(9);
        return view('list_hotel', compact('cities', 'city', 'hotels', 'sort_price', 'price_min', 'price_max' , 'star'));
    }

    public function about()
    {
        return view('about');
    }

    public function contact()
    {
        return view('contact');
    }



}
