<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\City;
use App\Models\Hotel;


class HotelController extends Controller
{
    public function show_list(Request $request)
    {
        $sort_price = $request->input('sort_price');
        $price_min = $request->input('price_min');
        $price_max = $request->input('price_max');
        $hotels = Hotel::where('name', '<>', ' ');

        $star = array();

        if($request->input('star1') == 'on')
        {
            array_push($star,1);
        }
        if($request->input('star2') == 'on')
        {
            array_push($star,2);
        }
        if($request->input('star3') == 'on')
        {
            array_push($star,3);
        }
        if($request->input('star4') == 'on')
        {
            array_push($star,4);
        }
        if($request->input('star5') == 'on')
        {
            array_push($star,5);
        }
        if($star != [])
        {
            $hotels = $hotels->whereIn('stars', $star);

        }

        if(is_null($price_min) == False)
        {
            $hotels = $hotels->where('price', '>', $price_min);
        }
        if(is_null($price_max) == False)
        {
            $hotels = $hotels->where('price', '<', $price_max);
        }

        if($sort_price == 1)
        {
            $hotels = $hotels->orderBy('price', 'asc');
        }

        if($sort_price == 2)
        {
            $hotels = $hotels->orderBy('price', 'desc');
        }
        $city = null;
        $cities = City::with('hotels')->get();
        $hotels = $hotels->orderBy('rank', 'asc')->paginate(9);
        return view('common.hotels', compact('cities', 'city', 'hotels', 'sort_price', 'price_min', 'price_max' , 'star'));
    }

    public function show($slug)
    {
        $hotel = Hotel::where('slug', $slug)->first();
        $cities = City::with('hotels')->get();
        if (!$hotel) {
            abort(403);
        }
        else {
            $relatedHotels = Hotel::whereIn('id', [$hotel->suggest1, $hotel->suggest2, $hotel->suggest3])->get();
            $reviews = $hotel->reviews()->orderBy('rating', 'asc')->get();
            return view('hotel_show', compact('hotel', 'relatedHotels', 'reviews', 'cities'));
        }
    }

    public function search(Request $request)
    {
        $search = $request->input('search');
        #$search = vn_to_str($search);
        $city_slug = $request->input('city');
        $cities = City::with('hotels')->get();
        $sort_price = $request->input('sort_price');
        $price_min = $request->input('price_min');
        $price_max = $request->input('price_max');
        $hotels = Hotel::where('name', '<>', ' ');

        $star = array();

        if($request->input('star1') == 'on')
        {
            array_push($star,1);
        }
        if($request->input('star2') == 'on')
        {
            array_push($star,2);
        }
        if($request->input('star3') == 'on')
        {
            array_push($star,3);
        }
        if($request->input('star4') == 'on')
        {
            array_push($star,4);
        }
        if($request->input('star5') == 'on')
        {
            array_push($star,5);
        }
        if($star != [])
        {
            $hotels = $hotels->whereIn('stars', $star);

        }


        if(is_null($price_min) == False)
        {
            $hotels = $hotels->where('price', '>', $price_min);
        }
        if(is_null($price_max) == False)
        {
            $hotels = $hotels->where('price', '<', $price_max);
        }

        if($sort_price == 1)
        {
            $hotels = $hotels->orderBy('price', 'asc');
        }

        if($sort_price == 2)
        {
            $hotels = $hotels->orderBy('price', 'desc');
        }

        if(is_null($city_slug))
        {
            $city = null;
            $hotels = $hotels
                ->where('name', 'LIKE', "%{$search}%")
                ->orWhere('description', 'LIKE', "%{$search}%")
                ->orWhere('address', 'LIKE', "%{$search}%")
                ->orderBy('rank', 'asc')
                ->paginate(9);
        }
        else
        {
            $city = City::where('slug', $city_slug)->first();
            $hotels = $hotels->where(function($q) use ($search, $city){
                $q->where([['name', 'LIKE', "%{$search}%"], ['city_id', $city->id]])
                ->orWhere([['description', 'LIKE', "%{$search}%"] , ['city_id', $city->id]])
                ->orWhere([['facilities', 'LIKE', "%{$search}%"] , ['city_id', $city->id]]);
            })->orderBy('rank', 'asc')->paginate(9);
        }
        return view('search', compact('hotels', 'search', 'city', 'cities', 'sort_price', 'price_min', 'price_max', 'star'));


    }

    public function vn_to_str($str)
    {

        $unicode = array(

        'a'=>'á|à|ả|ã|ạ|ă|ắ|ặ|ằ|ẳ|ẵ|â|ấ|ầ|ẩ|ẫ|ậ',

        'd'=>'đ',

        'e'=>'é|è|ẻ|ẽ|ẹ|ê|ế|ề|ể|ễ|ệ',

        'i'=>'í|ì|ỉ|ĩ|ị',

        'o'=>'ó|ò|ỏ|õ|ọ|ô|ố|ồ|ổ|ỗ|ộ|ơ|ớ|ờ|ở|ỡ|ợ',

        'u'=>'ú|ù|ủ|ũ|ụ|ư|ứ|ừ|ử|ữ|ự',

        'y'=>'ý|ỳ|ỷ|ỹ|ỵ',

        'A'=>'Á|À|Ả|Ã|Ạ|Ă|Ắ|Ặ|Ằ|Ẳ|Ẵ|Â|Ấ|Ầ|Ẩ|Ẫ|Ậ',

        'D'=>'Đ',

        'E'=>'É|È|Ẻ|Ẽ|Ẹ|Ê|Ế|Ề|Ể|Ễ|Ệ',

        'I'=>'Í|Ì|Ỉ|Ĩ|Ị',

        'O'=>'Ó|Ò|Ỏ|Õ|Ọ|Ô|Ố|Ồ|Ổ|Ỗ|Ộ|Ơ|Ớ|Ờ|Ở|Ỡ|Ợ',

        'U'=>'Ú|Ù|Ủ|Ũ|Ụ|Ư|Ứ|Ừ|Ử|Ữ|Ự',

        'Y'=>'Ý|Ỳ|Ỷ|Ỹ|Ỵ',

        );

        foreach($unicode as $nonUnicode=>$uni){

        $str = preg_replace("/($uni)/i", $nonUnicode, $str);

        }
        $str = str_replace(' ','_',$str);

        return $str;
    }
}
