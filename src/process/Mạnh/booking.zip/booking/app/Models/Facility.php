<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Facility extends Model
{
    public $timestamps = true;

    public function Hotel()
    {
        return $this->belongsToMany(Hotel::class);
    }
}
