<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateHotelsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('hotels', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->longText('img_url1');
            $table->longText('img_url2');
            $table->longText('img_url3');
            $table->integer('city_id');
            $table->string('slug');
            $table->longText('url1');
            $table->longText('url2');
            $table->longText('url3');
            $table->longText('url4');
            $table->integer('stars'); # trung bình
            $table->decimal('min_price', 15, 2); # Thấp nhhaast
            $table->integer('rating'); #trung bình
            $table->string('check_in');
            $table->string('check_out');
            $table->integer('number_review'); # Tổng
            $table->longText('address'); # lấy 1 cái
            $table->longText('description'); # lấy 1 cái
            $table->longText('nearby_places'); # lấy 1 cái
            $table->longText('facilities'); # lấy 1 cái
            $table->integer('rank');
            $table->integer('suggest1');
            $table->integer('suggest2');
            $table->integer('suggest3');
            $table->integer('suggest4');
            $table->integer('price1');
            $table->integer('price2');
            $table->integer('price3');
            $table->integer('price4');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('hotels');
    }
}
