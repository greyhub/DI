<?php

use Illuminate\Database\Seeder;

class CitysTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $citys = [
            ['name' => 'Hà Nội',
            'slug' => 'ha_noi',
            'url' => ' ',
            ],
            ['name' => 'Đà Nẵng',
            'slug' => 'da_nang',
            'url' => ' ',
            ],
            ['name' => 'Hồ Chí Minh',
            'slug' => 'ho_chi_minh',
            'url' => ' ',
            ],
            ['name' => 'Đà Lạt',
            'slug' => 'da_lat',
            'url' => ' ',
            ],
        ];
        foreach ($citys as $city) {
            if (!DB::table('city')->where('name', $city['name'])->first()) {
                DB::table('city')->insert([
                    'name' => $city['name'],
                    'slug' => $city['slug'],
                    'url' => $city['url'],
                ]);
            }
        }
    }
}
