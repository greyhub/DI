<?php

use Illuminate\Database\Seeder;

class HotelsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        for ($i = 0; $i < 10; $i++)
        {
            DB::table('hotels')->insert([
            'name' => 'Icon Saigon - LifeStyle Design Hotel',
            'city_id' => 1,
            'img_url1' => 'https://cf.bstatic.com/images/hotel/max1024x768/266/266443321.jpg',
            'img_url2' => 'https://cf.bstatic.com/images/hotel/max1024x768/266/266439209.jpg',
            'img_url3' => 'https://cf.bstatic.com/images/hotel/max1024x768/266/266439209.jpg',
            'slug' => 'icon_saigon_life_style',
            'url1' => 'https://www.booking.com/hotel/vn/icon-saigon-luxury-design.vi.html',
            'url2' => 'https://www.booking.com/hotel/vn/icon-saigon-luxury-design.vi.html',
            'url3' => 'https://www.booking.com/hotel/vn/icon-saigon-luxury-design.vi.html',
            'stars' => 4,
            'price' => 772.222,
            'rating' => 8.7,
            'check_in' => '14h',
            'check_out' => '12h',
            'number_review' => 1.174,
            'address' => '65-67 Hai Ba Trung, Quận 1, TP. Hồ Chí Minh, Việt Nam',
            'description' => ' Tọa lạc ở Thành phố Hồ Chí Minh, Icon Saigon - LifeStyle Design Hotel có nhà hàng, hồ bơi ngoài trời, trung tâm thể dục và quầy bar. Khách sạn 4 sao này cung cấp WiFi miễn phí, dịch vụ lễ tân 24 giờ và dịch vụ phòng. Chỗ nghỉ nằm gần các điểm tham quan nổi tiếng như Trụ sở UBND Thành phố Hồ Chí Minh, Bưu điện Trung tâm Sài Gòn và Nhà thờ Đức Bà. Tất cả phòng nghỉ tại Icon Saigon - LifeStyle Design đều được trang bị tủ để quần áo, bàn làm việc, TV màn hình phẳng và phòng tắm riêng. Khách sạn phục vụ bữa sáng kiểu lục địa hàng ngày. Các điểm tham quan nổi tiếng gần Icon Saigon - LifeStyle Design Hotel bao gồm Nhà Hát Lớn Sài Gòn, Trung tâm mua sắm Vincom và Trung tâm thương mại Union Square. Sân bay gần nhất là sân bay quốc tế Tân Sơn Nhất, cách khách sạn 7 km. ',
            'nearby_places' => "'Dinh Thống Nhất 1 km', 'Sri Thenday Yuttha Panin Temple 0,5 km', 'Bảo tàng Thành phố Hồ Chí Minh 0,5 km', 'Bến cảng Nhà Rồng 1 km', 'Bến Bạch Đằng 0,4 km', 'Trung tâm mua sắm Takashimaya Việt Nam 0,6 km', 'Nhà hát Opera 0,1 km', 'Trung tâm Thương mại Vincom Center A 0,3 km', 'Trụ sở Ủy ban Nhân dân 0,4 km', 'Lucky Plaza Ho Chi Minh 0,3 km', 'Trung tâm Thương mại Vincom 0,3 km', 'Nhà thờ Đức Bà 0,7 km', 'The New Playground 0,4 km', 'Bưu điện Trung tâm 0,6 km', 'Trung Tâm Thương Mại Diamond Plaza 0,8 km', 'Ben Thanh Street Food Market 0,8 km', 'Chợ Bến Thành 0,8 km', 'Ho Chi Minh City Hall 0,4 km', 'Bảo tàng Mỹ thuật 1 km', 'Sân bay Quốc tế Tân Sơn Nhất 7,4 km', 'Saigon Garden 0,4 km'",
            'policy' => '',
        ]);
        }

    }
}
